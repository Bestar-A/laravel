<?php

return [
    'name' => 'Upgrader',
    'permission_group' => ['System Upgrader']
];
