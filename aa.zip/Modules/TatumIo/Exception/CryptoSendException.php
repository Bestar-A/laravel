<?php
namespace Modules\TatumIo\Exception;
use Exception;

class CryptoSendException extends Exception
{
    //
}
